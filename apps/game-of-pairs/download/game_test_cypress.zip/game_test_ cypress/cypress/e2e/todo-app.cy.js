/// <reference types="cypress" />

describe('', () => {
  beforeEach(() => {
    cy.visit('http://localhost:3000');
  });
  const lendthUl = 4;
  // 1 работает
  it('В начальном состоянии игра должна иметь поле четыре на четыре клетки, в каждой клетке цифра должна быть невидима.', () => {
    cy.get('ul > li').should(($lis) => {
      expect($lis).to.have.length(lendthUl);
    });
    for (let i = 1; i <= lendthUl; i++) {
      cy.get(`ul li:nth-child(${i})`).should('not.have.class', 'open');
    }
  });

  // 2 работает
  function getRandomInt(min, max) {
    min = Math.ceil(min);
    max = Math.floor(max);
    return Math.floor(Math.random() * (max - min) + min); // Максимум не включается, минимум включается
  }

  it('2) Нажать на одну произвольную карточку. Убедиться, что она осталась открытой.', () => {
    cy.visit('http://localhost:3000');
    cy.get(`ul li:nth-child(${getRandomInt(1, 5)})`)
      .click()
      .should('have.class', 'open');
  });

  // 3 Работает
  it('3) Найти пару верхней левой карточки', () => {
    let counter = 1;

    function clickCards(cards) {
      cy.get(cards[counter]).click();
      const nextCard = cards[counter].textContent;
      cy.log('Вторая карточка' + nextCard);

      cy.get(cards[0]).click();
      const firstCard = cards[0].textContent;
      cy.log('Первая карточка' + firstCard);

      if (firstCard === nextCard) {
        cy.get(cards[0]).should('have.class', 'success');
        cy.get(cards[counter]).should('have.class', 'success');
      } else {
        counter++;
        cy.wait(500);
        clickCards(cards);
      }
    }

    cy.get('.iiem').then(($cards) => {
      clickCards($cards);
    });
  });

  // 4 Нажать на левую верхнюю карточку, затем на следующую. Если это пара, то повторять со следующими двумя карточками, пока не найдутся непарные карточки. Проверить, что после нажатия на третью карточку две несовпадающие карточки становятся закрытыми.

  it('4) Выиграть  игру', () => {
    let startCounter = 0;
    let counter = 1;
    let two = 0;
    let nextCard = null;
    let firstCard = null;

    function clickStart(cards) {
      cy.get(cards[startCounter]).click();
      firstCard = cards[startCounter].textContent;
      console.log('Первая карточка' + firstCard);
    }

    function clickNext(cards) {
      cy.get(cards[counter]).click();
      nextCard = cards[counter].textContent;
      console.log('Вторая карточка' + nextCard);
    }

    function clickCards(cards) {
      clickStart(cards);

      if (firstCard === nextCard) {
        cy.get(cards[startCounter]).should('have.class', 'success');
        cy.get(cards[counter]).should('have.class', 'success');
        two++;
        startCounter++;
        if (counter === startCounter) startCounter++;
        if (counter === startCounter + 1) counter++;
        counter = startCounter + 1;
        if (two < lendthUl / 2) {
          clickNext(cards);
          cy.wait(500);
          clickCards(cards);
        }
      } else {
        if (two < lendthUl / 2) {
          counter++;
          clickNext(cards);
        }
        if (counter !== 1) {
          // Закрыты ли карточки
          cy.get(cards[counter - 1]).should('not.have.class', 'open');
          cy.get(cards[startCounter]).should('not.have.class', 'open');
        }
        cy.wait(500);
        clickCards(cards);
      }
    }

    cy.get('.iiem').then(($cards) => {
      clickNext($cards);
      clickCards($cards);
    });
  });
});
