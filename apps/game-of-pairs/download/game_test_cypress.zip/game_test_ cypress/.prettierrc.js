module.exports = {
    singleQuote: true,
}
