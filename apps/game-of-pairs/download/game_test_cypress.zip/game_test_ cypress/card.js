class Card { // класс

    _open = false;
    _success = false;

    constructor(container, cardNumber, flip) {
        this.cardNumber = document.createElement ('li');
        this.cardNumber.classList.add('iiem');
        this.cardNumber.setAttribute('tabindex', '0');
        this.number = cardNumber;

        // Открываем карточку
        this.cardNumber.addEventListener('click', () => {
            if (this.open === false && this._success === false) {
                this.open = true;
                flip(this);
            }
        })

        container.append(this.cardNumber);
    }

    set number(value) {
        this._number = value;
        this.cardNumber.textContent = value;
    }

    get number() {
        return this._number
    }

    set open(value) {
        this._open = value;
        value ? this.cardNumber.classList.add('open') : this.cardNumber.classList.remove('open');
    }

    get open() {
        return this._open;
    }

    set success(value) {
        this._success = value;
        value ? this.cardNumber.classList.add('success') : this.cardNumber.classList.remove('success');
    }

    get success() {
        return this._success;
    }
}

export class AmazingCard extends Card {

}

